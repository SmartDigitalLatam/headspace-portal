#!/usr/bin/env node
/* eslint-disable */
/* Adapted from nodemon's postinstall: https://github.com/remy/nodemon/blob/master/package.json */

var msg =
  'Use styled-components at work? Consider supporting our development efforts at https://opencollective.com/styled-components';

console.log(msg);
