import {Plugin} from 'jss'

export default function jssPluginSyntaxGlobal(): Plugin
