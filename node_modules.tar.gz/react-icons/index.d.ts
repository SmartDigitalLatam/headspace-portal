// THIS FILE IS AUTO GENERATED
import * as m from './lib/esm/index.d.ts'
export default m
    