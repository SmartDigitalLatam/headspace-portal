// THIS FILE IS AUTO GENERATED
module.exports = require('./lib/cjs/index.js');