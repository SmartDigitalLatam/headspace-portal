export * from 'rxjs-compat/util/TimeoutError';
