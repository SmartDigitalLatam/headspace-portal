export * from 'rxjs-compat/util/hostReportError';
