export * from 'rxjs-compat/util/root';
