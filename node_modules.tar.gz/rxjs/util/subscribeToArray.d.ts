export * from 'rxjs-compat/util/subscribeToArray';
