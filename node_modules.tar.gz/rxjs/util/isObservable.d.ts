export * from 'rxjs-compat/util/isObservable';
