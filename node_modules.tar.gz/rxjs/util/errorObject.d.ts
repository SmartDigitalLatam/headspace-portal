export * from 'rxjs-compat/util/errorObject';
