export * from 'rxjs-compat/observable/fromEvent';
