export * from 'rxjs-compat/observable/UsingObservable';
