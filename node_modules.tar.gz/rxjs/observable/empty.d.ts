export * from 'rxjs-compat/observable/empty';
