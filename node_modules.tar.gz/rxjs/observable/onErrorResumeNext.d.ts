export * from 'rxjs-compat/observable/onErrorResumeNext';
