export * from 'rxjs-compat/observable/FromEventPatternObservable';
