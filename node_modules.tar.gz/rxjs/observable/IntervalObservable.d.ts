export * from 'rxjs-compat/observable/IntervalObservable';
