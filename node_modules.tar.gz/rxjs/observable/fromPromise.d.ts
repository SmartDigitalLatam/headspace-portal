export * from 'rxjs-compat/observable/fromPromise';
