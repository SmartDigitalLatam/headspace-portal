export * from 'rxjs-compat/observable/ConnectableObservable';
