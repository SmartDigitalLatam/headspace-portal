export * from 'rxjs-compat/observable/merge';
