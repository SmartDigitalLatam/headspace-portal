export * from 'rxjs-compat/observable/of';
