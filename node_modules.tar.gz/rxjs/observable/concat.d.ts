export * from 'rxjs-compat/observable/concat';
