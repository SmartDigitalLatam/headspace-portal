export * from 'rxjs-compat/observable/interval';
