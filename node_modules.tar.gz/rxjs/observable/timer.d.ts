export * from 'rxjs-compat/observable/timer';
