export declare function getSetTimeoutFn(): any;
