'use strict'

module.exports = require('http').STATUS_CODES
